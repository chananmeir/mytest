
# ComfyUI-llama-cpp-cli

A tiny ComfyUI node that calls a local `llama.cpp` executable with a `.gguf` LLM model.
- No pip packages required
- Works in sandboxed environments (e.g., MimicPC)
- Install via **ComfyUI-Manager → Custom Nodes → Install from Git** (or ZIP)

## Install (from Git)

1. Create a GitHub repo named **ComfyUI-llama-cpp-cli**.
2. Upload all files from this ZIP to the repo root.
3. In ComfyUI, open **Manager → Custom Nodes → Install from Git** and paste your repo URL.
4. Restart ComfyUI.

## Install (from ZIP)

1. In ComfyUI, open **Manager → Custom Nodes → Install from ZIP**, select this ZIP.
2. Restart ComfyUI.

## Expected files on disk

- llama binary (executable): `/models/llm/llama`
- gguf model: `/models/llm/mistral-7b-instruct-v0.1.Q4_0.gguf`

> You can override both paths on the node inputs.

## Usage

1. Add node **“LLM • llama.cpp (CLI)”** (search `LlamaCppCLINode`).
2. Enter a prompt; adjust `max_tokens` if needed.
3. (Optional) Set `llama_bin` and `model_path` if your paths differ.
4. Connect the output `text` anywhere you want (e.g., into a prompt builder).

## Troubleshooting

- If you see “binary not found”, fix the `llama_bin` path.
- If you see “model not found”, fix `model_path`.
- If llama.cpp returns an error, the node will pass it through so you can see it.

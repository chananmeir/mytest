
# ComfyUI-llama-cpp-cli
# Minimal ComfyUI custom node pack that calls a local llama.cpp binary via subprocess.
# No pip dependencies required.

from .llama_cli import NODE_CLASS_MAPPINGS, NODE_DISPLAY_NAME_MAPPINGS
